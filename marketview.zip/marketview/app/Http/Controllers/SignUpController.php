<?php

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class SignUpController extends Controller
{
    public function signup_func() {

        $request = request();
        // aggiungi in tabella
       
            $nuovoUtente =  User::create([
            'name' => $request['nome'],
            'email' => $request['email'],
            'password' =>bcrypt($request['password']),
            'tipo' => $request['tipo'],
            ]);
            if ($nuovoUtente ) {
                Session::put('id', $nuovoUtente->id);
                return redirect('home');
            } 
            else {
                return redirect('signup')->withInput();
            }
  
    }

    public function check($query) {
             $exist = User::where('email', $query)->exists();
             return ['exists' => $exist];
    }

    public function pag_signup() {
        return view('signup');
    } 
}

?>