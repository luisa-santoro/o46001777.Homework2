<?php


use Illuminate\Routing\Controller;
use App\Models\Catene;
use App\Models\PrefCat;
use App\Models\Articoli;
use App\Models\Negozi;
use Facade\FlareClient\Http\Response;
use PhpParser\Node\Expr\FuncCall;
use Symfony\Component\HttpFoundation\Request;

class StoreController extends Controller
{
    public function view(){
        return view('catene_musicali');
    }


    public function carica(){
        $catene = Catene::all();
        return $catene;
    }

  
    public function viewNegozi(){
        return view('negozi');
    }

    public function apiNegozio(Request $request)
    {
        $catena_negozi =  $request->get("catena_negozi");
        $negozio = Negozi::where('nome_catena_app', '=', $catena_negozi)->get();
        return $negozio;
    }

  
  
    public function viewArticoli(){
        return view('articoli');
    }

    public function apiArticolo(Request $request)
    {
        $articoli =  $request->get("articolo");
        $articolo = Articoli::where('nome_neg_app', '=', $articoli)->get();
        return $articolo;
    }
    

}



?>