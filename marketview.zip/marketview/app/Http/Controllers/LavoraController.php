<?php

use App\Models\Dipendenti;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class LavoraController extends Controller
{
    public function lavora_view() {
        return view("lavoraconnoi");
    }
      


   
        public function lavora_func() {
            // request 
            $request = request();
            // aggiungi in tabella  
                $nuovoUtente =  Dipendenti::create([
                'nome' => $request['nome'],
                'data_nascita' => $request['data_nascita'],
                'telefono' => $request['telefono'],
                'email' => $request['email'],
                'password' =>bcrypt($request['password']),
                ]);
                // aggiunta anche agli user per login
                    User::create([
                    'name' => $request['nome'],
                    'email' => $request['email'],
                    'password' =>bcrypt($request['password']),
                    'tipo' => "dipendente",
                    ]);

                if ($nuovoUtente ) {
                    Session::put('id', $nuovoUtente->id);
                    return redirect('home');
                } 
                else {
                    return redirect('lavoraconnoi')->withInput();
                }    
        }
        
        public function check($query) {
            $exist = User::where('email', $query)->exists();
            return ['exists' => $exist];
   }


}

?>