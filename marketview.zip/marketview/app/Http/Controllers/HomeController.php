<?php

use App\Models\Catene;
use App\Models\Negozi;
use App\Models\Articoli;
use App\Models\PrefCat;
use App\Models\PrefNeg;
use App\Models\PrefArt;
use Facade\FlareClient\Http\Response;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Http;





class HomeController extends Controller
{
        public function home_func() {
            return view("home");
        }

       public function ricerca_spotify($query) {   
            $token = Http::asForm()->withHeaders([
                'Authorization' => 'Basic '.base64_encode(env('SPOTIFY_CLIENT_ID').':'.env('SPOTIFY_CLIENT_SECRET')),
            ])->post('https://accounts.spotify.com/api/token', [
                'grant_type' => 'client_credentials',
            ]);
            if ($token->failed()) abort(500);
    
            $response = Http::withHeaders([
                'Authorization' => 'Bearer '.$token['access_token']
            ])->get('https://api.spotify.com/v1/search', [
                'type' => 'album',
                'q' => $query
            ]);
            if($response->failed()) abort(500);
    
            return $response->body();
        }
        
        
        
        public function preferiti_view(){
            return view("preferiti");
        } 

        public function elementi(){ // json per avere catene,negozi ed articoli preferiti

            $id_sess = session('id');
            $pref_cat = PrefCat::all();
            $catene = Catene::all();
            $array_catene = array();


            for ($i=0; $i<count($catene);$i++) {
                for ($k=0; $k<count($pref_cat); $k++) {
                    if (($id_sess == $pref_cat[$k]->codice_utente ) && ($catene[$i]->codice_cat === $pref_cat[$k]->codicecat)) {
                        $array_catene[]= [
                            'titolo_catena' => $catene[$i]->nome,
                            'immagine_catena' => $catene[$i]->immagine,
                            'desc_catena' => $catene[$i]->descrizione
                    ];
                    }
                }
            }
                // return $array_catene;  

        $pref_neg = PrefNeg::all();
            $negozi= Negozi::all();
            $array_negozi = array();
         
         
             for ($i=0; $i<count($negozi);$i++) {
                for ($k=0; $k<count($pref_neg); $k++) {
                    if ( ($id_sess == $pref_neg[$k]->codice_utente ) && ($negozi[$i]->codice_neg === $pref_neg[$k]->codiceneg)) {
                        $array_negozi[] = [
                            'titolo_negozio' => $negozi[$i]->nome,
                            'desc_negozio' => $negozi[$i]->descrizione
                    ];
                    }
                }
            }

         //   return $array_negozi; 

            $pref_art = PrefArt::all();
            $articoli= Articoli::all();
            $array_articoli = array();

         for ($i=0; $i<count($articoli);$i++) {
                for ($k=0; $k<count($pref_art); $k++) {
                    if ( ($id_sess == $pref_cat[$k]->codice_utente ) && ($articoli[$i]->codice_art === $pref_art[$k]->codiceart) ){
                        $array_articoli[] = [
                            'titolo_articolo' => $articoli[$i]->nome,
                            'immagine_articolo' => $articoli[$i]->immagine,
                            'desc_articolo' => $articoli[$i]->prezzo
                    ];
                    }
                }
            }   // return $array_articoli; 
     

             $array_finale = array();

                $array_finale[] = [
                    'catene' => $array_catene,
                    'negozi'  => $array_negozi,
                    'articoli'  => $array_articoli,
                ];
                return $array_finale;
        } 

}
?>