<?php

use App\Models\Articoli;
use App\Models\Catene;
use App\Models\Negozi;
use App\Models\PrefCat;
use App\Models\PrefNeg;
use App\Models\PrefArt;

use Illuminate\Routing\Controller;

use Illuminate\Support\Facades\Session;

class PrefController extends Controller
{
    public function add_pref_cat($query) {
    
        PrefCat::create([
            'codice_utente' => Session::get('id'),
            'codicecat' => Catene::where('nome',$query)->first()->codice_cat,
            'nome_utente' => Session::get('name'),
            'nome_catena' => $query,
            ]); 
        
    }
    public function rem_pref_cat($query) {
    
        PrefCat::where('codice_utente', session('id'))->where('codicecat', Catene::where('nome',$query)->first()->codice_cat)->where('nome_utente',  session('name'))->where('nome_catena',$query)->delete();
     

    }


    public function add_pref_neg($query) {
    

        PrefNeg::create([
            'codice_utente' => Session::get('id'),
            'codiceneg' => Negozi::where('nome',$query)->first()->codice_neg,
            'nome_utente' => Session::get('name'),
            'nome_neg' => $query,
            ]); 
        
    }
    public function rem_pref_neg($query) {
        PrefNeg::where('codice_utente', session('id'))->where('codiceneg', Negozi::where('nome',$query)->first()->codice_neg)->where('nome_utente',  session('name'))->where('nome_neg',$query)->delete();

   
    }


    public function add_pref_art($query) {
    

        PrefArt::create([
            'codice_utente' => Session::get('id'),
            'codiceart' => Articoli::where('nome',$query)->first()->codice_art,
            'nome_utente' => Session::get('name'),
            'nome_art' => $query,
            ]); 
        
    }
    public function rem_pref_art($query) {
        
     //  PrefArt::where('codice_utente', session('id'))->where('codice_art', "2")->delete();
     PrefArt::where('codice_utente', session('id'))->where('codiceart', Articoli::where('nome',$query)->first()->codice_art)->where('nome_utente',  session('name'))->where('nome_art',$query)->delete();
    }

   
}

?>