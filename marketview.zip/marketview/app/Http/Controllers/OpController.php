<?php

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\Dipendenti;
use App\Models\Articoli;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;

class OpController extends Controller
{
    public function op_func(){
       return view("operazioni");
    }

    public function carica(){
            $lista = Dipendenti::where('stipendio','=',0)->get();
            return $lista;
    }
 
    public function  carica_art(){
        $articoli = Articoli::all();
        return $articoli;
    }

    public function sendOp(){
        $request = request();
    //    echo $request;
        //echo $request['new_dip'];
       // echo $request['input_stip'];
        if(strcmp($request['input_stip'], '' ) !== 0){  // aggiungi spiegazione !!
            $dipendente = Dipendenti::where('codice_dip',$request['new_dip'])->first();
            $dipendente->stipendio = $request['input_stip'];
            $dipendente->save();
          //  echo $dipendente;
        }
        if (strcmp($request['input_prezzo'], '' ) !== 0) {
            $articolo = Articoli::where('codice_art',$request['input_articolo'])->first();
            $articolo->prezzo = $request['input_prezzo'];
            $articolo->save();            
        }

        return view("operazioni");
}

    public function listatuttidip(){
        $lista = Dipendenti::all();
        return $lista;
    }
}

?>