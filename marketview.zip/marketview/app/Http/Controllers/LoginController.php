<?php

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Crypt;

class LoginController extends Controller{

    public function login_func() {
        return view('login');
    }


    public function check() {
        $user = User::where('email', request('email'))->first();
        $tipo = $user['tipo'];
        $hashed = $user['password']; // pss hash in db
        $pass_input = request('password'); //input in login
        
        if (($user != null) && (Hash::check($pass_input, $hashed))) {
            Session::put('id', $user->id);
            Session::put('name', $user->name);
            Session::put('email', $user->email);
            
            if (strcmp("manager", $tipo) == 0) {
                return redirect('operazioni');
            } else {
                return redirect('home');
            }
        }
    }

   public function logout() {
       Session::flush();
       return redirect('home');
   }
}

?>