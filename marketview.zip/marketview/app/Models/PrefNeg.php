<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class PrefNeg extends Model
{

    protected $table = "pref_neg";

        public $timestamps = false;
        public $incrementing = false;

         protected $fillable = [
            'codice_utente',
            'codiceneg',
            'nome_utente',
            'nome_neg',
        ];
        
       

}