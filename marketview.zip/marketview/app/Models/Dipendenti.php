<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Dipendenti extends Model
{
        protected $table = "dipendente";

        protected $primaryKey = "codice_dip";

        public $timestamps = false;

         protected $fillable = [
            'codice_dip',
            'nome',
            'data_nascita',
            'telefono',
            'email',
            'password',
            'stipendio',
            'bonus',
        ];

}
