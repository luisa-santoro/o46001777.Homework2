<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Catene extends Model
{
        protected $table = "catena_negozi";

        protected $primaryKey = "codice_cat";

        public $timestamps = false;

         protected $fillable = [
            'codice_cat',
            'nome',
            'tipo',
            'immagine',
            'descrizione',
            'num_negozi',
        ];


        public function prefUtente(){
                return $this->belongsToMany('App\Models\User','pref_cat');
        }


}
