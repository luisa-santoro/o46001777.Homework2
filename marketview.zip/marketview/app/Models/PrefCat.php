<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;


class PrefCat extends Model
{

    protected $table = "pref_cat";

        public $timestamps = false;
        public $incrementing = false;

         protected $fillable = [
            'codice_utente',
            'codicecat',
            'nome_utente',
            'nome_catena',
        ];
        
       

}