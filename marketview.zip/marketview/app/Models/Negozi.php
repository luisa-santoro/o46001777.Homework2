<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Negozi extends Model
{
        protected $table = "negozio";

        protected $primaryKey = "codice_neg";

        public $timestamps = false;

         protected $fillable = [
            'codice_neg',
            'nome',
            'catena_app',
            'nome_catena_app',
	        'luogo',
        ];

     
        public function prefUtente(){
                return $this->belongsToMany('App\Models\User','pref_neg');
        }

}