<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Articoli extends Model
{
        protected $table = "articolo";

        protected $primaryKey = "codice_art";

        public $timestamps = false;

         protected $fillable = [
            'codice_art',
            'negozio_app',
            'nome_neg_app',
	    'nome',
            'prezzo',
            'tipo',
            'immagine',
            'descrizione',
            'casa_prod',
            'num_pagine',
             'autore',
        ];
        public function prefUtente(){
                return $this->belongsToMany('App\Models\User','pref_art');
        }

}
