

 const IMG_REM_PREF = 'https://cdn.iconscout.com/icon/free/png-256/minus-2652914-2202831.png';

function onResponse(response){
    return response.json();
}

function onJson(json){

    //console.log(json);

    // Memorizzo le sezioni
    const sez_catene = document.querySelector('.sez_catene'); // ric: in querySel
    // selezione classe col .nomeclasse senza punto non lo prende
    const sez_negozi = document.querySelector('.sez_negozi');
    const sez_articoli = document.querySelector('.sez_articolo');

    //memorizzo i dati
    const catene = json[0].catene;
    const negozi = json[0].negozi;
    const articoli = json[0].articoli;

   // console.log(catene);
   // console.log(negozi);
    console.log(articoli);
    // li appendo uno ad uno alla pagina

     // SEZIONE CATENE

    for(let i = 0; i< catene.length; i++){
       
        const dati_catene = catene[i];
        const title = catene[i].titolo_catena;
        const image = catene[i].immagine_catena;
        const desc = catene[i].desc_catena;
        console.log(dati_catene);

        const box = document.createElement('div');
        box.classList.add("square");
        sez_catene.appendChild(box);

        // creo i piccoli box

        const titolo = document.createElement('h1');
        titolo.setAttribute("style", "position: relative;");
        titolo.textContent = title;
        box.appendChild(titolo);

        const img = document.createElement('img');
        img.classList.add("settingImg");
        img.src = image;
        box.appendChild(img);

    
        const descrizione = document.createElement('p');
        descrizione.textContent =desc;
        box.appendChild(descrizione);

       
        const pref_cat = document.createElement("img");
        pref_cat.src = IMG_REM_PREF;
        pref_cat.classList.add("pref_rem");
        pref_cat.addEventListener("click", remPrefCat);
        box.appendChild(pref_cat);
        
        }
    

     // SEZIONE NEGOZI
     
    for(let i = 0; i< negozi.length; i++){
        const dati_negozi = negozi[i];
        const title_n = negozi[i].titolo_negozio;
        const desc_n= negozi[i].desc_negozio;
        console.log(dati_negozi);

        const box_n = document.createElement('div');
        box_n.classList.add("square");
        sez_negozi.appendChild(box_n);

        // creo i piccoli box per i negozi

        const titolo_n = document.createElement('h1');
        titolo_n.setAttribute("style", "position: relative;");
        titolo_n.textContent = title_n;
        box_n.appendChild(titolo_n);


        const descri_n = document.createElement('p');
        descri_n.textContent = desc_n;
        box_n.appendChild(descri_n);

        const pref_neg = document.createElement("img");
        pref_neg.src = IMG_REM_PREF;
        pref_neg.classList.add("pref_rem");
        pref_neg.addEventListener("click", remPrefNeg);
        box_n.appendChild(pref_neg);
       
    }

    

    
         // SEZIONE ARTICOLI
     
    for(let i = 0; i< articoli.length; i++){
        const dati_articoli = articoli[i];
        const title_a = articoli[i].titolo_articolo;
        const image_a = articoli[i].immagine_articolo;
        const desc_a= articoli[i].desc_articolo;
        console.log(dati_articoli);

        const box_a = document.createElement('div');
        box_a.classList.add("square");
        sez_articoli.appendChild(box_a);

        // creo i piccoli box per i negozi

        const titolo_a = document.createElement('h1');
        titolo_a.setAttribute("style", "position: relative;");
        titolo_a.textContent = title_a;
        box_a.appendChild(titolo_a);

        const img_a = document.createElement('img');
        img_a.classList.add("settingImg");
        img_a.src = image_a;
        box_a.appendChild(img_a);

        const descri_a= document.createElement('p');
        descri_a.textContent = " € " + desc_a;
        box_a.appendChild(descri_a);


        const pref_art= document.createElement("img");
        pref_art.src = IMG_REM_PREF;
        pref_art.classList.add("pref_rem");
        pref_art.addEventListener("click", remPrefArt);
        box_a.appendChild(pref_art);

        }
   
}





function remPrefCat(event){
    const title_remove=event.currentTarget.parentNode.querySelector('h1');
    let pref_remove=event.currentTarget.parentNode.querySelector('.pref');
    const box_remove=event.currentTarget.parentNode;
    const titolo_out = title_remove.textContent;
    if(pref_remove === null){
        pref_remove= event.currentTarget.parentNode.querySelector('.pref_rem');
    }

    if(pref_remove.src === IMG_REM_PREF){
        console.log(titolo_out);
         fetch('rem_cat/'+titolo_out);   
             // rimuovi da box   
        box_remove.classList.remove("square");
        box_remove.innerHTML = '';
       console.log(box_remove);
    } 
}
 


function remPrefNeg(event){
    const title_remove=event.currentTarget.parentNode.querySelector('h1');
    let pref_remove=event.currentTarget.parentNode.querySelector('.pref');
    const box_remove=event.currentTarget.parentNode;
    const titolo_out = title_remove.textContent;
    if(pref_remove === null){
        pref_remove= event.currentTarget.parentNode.querySelector('.pref_rem');
    }

    if(pref_remove.src === IMG_REM_PREF){
        console.log(titolo_out);
         fetch('rem_neg/'+titolo_out);   
             // rimuovi da box   
        box_remove.classList.remove("square");
        box_remove.innerHTML = '';
       console.log(box_remove);
    } 
}


function remPrefArt(event){
    const title_remove=event.currentTarget.parentNode.querySelector('h1');
    let pref_remove=event.currentTarget.parentNode.querySelector('.pref');
    const box_remove=event.currentTarget.parentNode;
    const titolo_out = title_remove.textContent;
    if(pref_remove === null){
        pref_remove= event.currentTarget.parentNode.querySelector('.pref_rem');
    }

    if(pref_remove.src === IMG_REM_PREF){
        console.log(titolo_out);
         fetch('rem_neg/'+titolo_out);   
             // rimuovi da box   
        box_remove.classList.remove("square");
        box_remove.innerHTML = '';
       console.log(box_remove);
    } 
}
 




fetch('/elementi').then(onResponse).then(onJson);