<html>
<link href='{{ url("https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap")}}' rel="stylesheet">
<link rel="stylesheet" href='{{ url("./css/form_style.css")}}' >
    <body style="background-color: black;">
          <form  name='login' method='post' action="{{ route('login') }}">
            <input name='_token' type='hidden' value={{csrf_token()}}>
            <p style="font-size: 30px;">  L O G I N </p>
            <p> Inserisci la tua Email:  </p>
            <input type='text'placeholder="Scrivi qui..." id="inputUser" name="email" required>
            <p> Inserisci la tua password:</p>
            <input type='password'placeholder="Scrivi qui..." id="inputPass" name="password" required><br><br>
            <input type='submit' id='submit' value='Invia'>
            <p>&ensp; &ensp; Non sei ancora registrato?&ensp;&ensp;</p>
             <a style="font-size: 15px; text-decoration: none; border: 1px solid white;" href={{ route('signup') }} id="submit">Clicca qui!</a>
        </form>
    </body>
</html>
