<html>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/form_style.css">
      <script src='{{asset("./js/signup.js")}}' defer></script>
      <script type="text/javascript">  const SIGNUP = "{{route('signup')}}";
</script>
    <body>
        <form method='post' id="form"  action="{{ route('signup') }}">
        <input type='hidden' name='_token' value={{csrf_token()}}></input>
            <p style="font-size: 30px;" > R E G I S T R A Z I O N E</p>
            <p>Inserisci il tuo nome:    </p>
            <input type='text'placeholder="Scrivi qui..." id='input_user' name="nome" required>
            <p> Inserisci la tua e-mail:</p>
            <input type='text'placeholder="Scrivi qui..." id='input_user' name="email" required>
            <br> <span id="emailerr" class="hidden"> </span>
            <p> Inserisci la tua password:</p>
            <input type='password'placeholder="Scrivi qui..." id='input_user'name="password" required>
            <br> <span id="pswerr" class="hidden"> </span>
            <p> &ensp; &ensp; &ensp; &ensp; Sei un cliente o un manager?&ensp; &ensp;&ensp; &ensp;</p>
            <input type='text'placeholder="Scrivi qui..."  id='input_user' name="tipo" required > <br><br>
            <input type='submit' id='submit' value='Invia'>
        </form>
        <section>
        <div id='errori' class='hidden'></div>
   </section>
    </body>
</html>