<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <link rel="stylesheet" href="./css/catene_musicali.css">
        <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap" rel="stylesheet">
        <script src="./js/negozi_musicali.js" defer></script>
        <script>  const NEGOZI = "{{route('negozi')}}";</script>
        <script>  const ARTICOLI = "{{route('articoli')}}";</script>
    </head>
    <body>
        <h1>Ecco i Negozi</h1>
        <h2>Cerca Store: <input type="text" placeholder="Scrivi qui..." id="box_ricerca" style="margin-left: 10px"></h2>
        <section>
            <div id="Preferiti" class="hidden">
                <p>I preferiti che hai scelto:</p>
                <div id="fav_items"></div>
            </div>
            <div id="box">
                <div id="grid"></div>
            </div>
        </section>
    </body>
</html>
