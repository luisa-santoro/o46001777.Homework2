<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="utf-8">
        <title>Market View</title>
        <link rel="preconnect" href='{{ url("https://fonts.gstatic.com")}}'>
        <link href='{{ url("https://fonts.googleapis.com/css2?family=Lobster&family=Train+One&display=swap")}}' rel="stylesheet">
        <link rel="preconnect" href='{{ url("https://fonts.gstatic.com")}}'>
        <link rel="preconnect" href='{{ url("https://fonts.gstatic.com")}}'>
        <link href='{{url("https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap")}}' rel="stylesheet">
        <link rel="preconnect" href='{{ url("https://fonts.gstatic.com")}}'>
        <link href='{{ url("https://fonts.googleapis.com/css2?family=Lacquer&display=swap")}}' rel="stylesheet">
        <link href='{{ url("https://fonts.googleapis.com/css?family=Lora:400,400i|Open+Sans:400,700")}}' rel="stylesheet">
        <script src="./js/mhw3_spotify.js" defer></script>
        <script src="./js/mhw3_holidays.js" defer></script>
        <script src="./js/mhw3_newapi.js" defer></script>
        <link rel="stylesheet" href="./css/home.css">
    </head>
<body>
    <header>
        <nav>
            <div id="logo">
                Market View
            </div>

            <div id="links">

              @if (session("email") ==! null)
                <a>Bentornato/a </a>   {{ Session::get('name')}}
                <a href='{{ route("logout")}}' class="button">Logout</a>
              @else
                   <a href= '{{ route("login")}}' class="button">Login</a>
              @endif
                <a href='{{ route("lavoraconnoi")}}' class="button">Lavora Con Noi</a>
                <a href='{{ route("chisiamo")}}' class="button">Chi Siamo</a>
               <a  href='{{ route("contatti")}}' class="button">Contatti</a>
            </div>

            <div id="menu">
                <div></div>
                <div></div>
                <div></div>
              </div>
        </nav>

        <h1>
            Ovunque tu sia, noi ci siamo.<br/>
        </h1>
    </header>


               <div id="flex-container">
                   <div class="flex-item">
                    <a href='{{ url("catene_musicali")}}' class="home_link">Store Musicali</a><br>
                 </div>

                 @if(session('id')==!null)
                 <div class="flex-item">
                    <a href='{{ url("preferiti")}}' class="home_link">I tuoi preferiti</a><br>
                 </div>
                @endif
               </div>

               <form id="form_a" >
         
                   <p>Cerca qui sotto la musica che troverai nei nostri store musicali!</p>
                   <input type='text'  placeholder="Scrivi qui..." id='album'  >
                   <input type='submit' id='submit'value='Cerca'>
                   <input type='hidden' name='_token' value={{csrf_token()}}></input>
                </form>
                <section id="box_album">
                </section>

                 <form id="form_h" >
                    <p>Controlla qui sotto il Paese in cui cerchi i nostri store, a causa delle festività potrebbero essere chiusi  </p>
                    <p>( Inserisci il codice del paese: es. Italia "it" ) </p>
                    <input type='text' placeholder="Scrivi qui..." id='holidays_country' >
                    <input type='submit' id='submit' value='Cerca'>
                 </form>
            <section id="box_holidays">
            </section>


            <form id="form_tre" >
                <p> Inserisci qui sotto la tua e-mail per restare aggiornato</p>
                <input type='text'placeholder="Scrivi qui..."id='email_input' >
                <input type='submit' id='submit' value='Cerca'>
             </form>
        <section id="box_email">
        </section>
    <footer>
        <p> Powered by Luisa Santoro o46001777</p>
      </footer>
</body>
</html>

  <!-- questo è un commento -->