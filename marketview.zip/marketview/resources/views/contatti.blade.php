<html>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap" rel="stylesheet">
<body style="background-color: #040404;">
  
  <p
        style="top: 50px;
        display: block;
        position: absolute;
        padding: 22px;
        margin: 2px solid white;
        right: 40%;  
        left: 30%; 
         display: block;
        text-align: center;
        color: white;
        font-family: 'Work Sans';
        font-size: 20px;
        border: 1px solid;">

         Hai dubbi? Contattaci alla seguente e-mail! 
        marketview@gmail.com
    </p>
</body>
</html>