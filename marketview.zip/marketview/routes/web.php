<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/home', 'HomeController@home_func')->name('home');
Route::get('/preferiti', 'HomeController@preferiti_view')->name('preferiti');
Route::get('/elementi', 'HomeController@elementi')->name('elementi');
Route::get('/ricerca_spotify/{query}', "HomeController@ricerca_spotify")->name('ricerca_spotify/');


Route::get('/login', 'LoginController@login_func')->name('login');
Route::post('/login', 'LoginController@check');
Route::get('/logout', 'LoginController@logout')->name('logout');

Route::get('/signup', 'SignUpController@pag_signup')->name('signup');
Route::post('/signup', 'SignUpController@signup_func');
Route::get('/signup/email/{query}', 'SignUpController@check');


Route::get('/lavoraconnoi', 'LavoraController@lavora_view')->name('lavoraconnoi');
Route::post('/lavoraconnoi', 'LavoraController@lavora_func');
Route::get('/lavoraconnoi/email/{query}', 'LavoraController@check');




Route::get('/catene_musicali', 'StoreController@view')->name('catene_musicali');
Route::get('/catene', 'StoreController@carica')->name('catene');
Route::get('/negozi/api', 'StoreController@apiNegozio')->name('negozio');
Route::get('/negozi', 'StoreController@viewNegozi')->name('negozi');
Route::get('/articoli/api', 'StoreController@apiArticolo')->name('articolo');
Route::get('/articoli', 'StoreController@viewArticoli')->name('articoli');


Route::get('/operazioni', 'OpController@op_func')->name('operazioni');
Route::get('/lista', 'OpController@carica')->name('lista');
Route::post('/sendOp', 'OpController@sendOp')->name('sendOp');
Route::get('/listatuttidip', 'OpController@listatuttidip')->name('listatuttidip');
Route::get('/lista_art', 'OpController@carica_art')->name('lista_art');

Route::get('/add_cat/{query}', 'PrefController@add_pref_cat');
Route::get('/rem_cat/{query}', 'PrefController@rem_pref_cat');
Route::get('/add_neg/{query}', 'PrefController@add_pref_neg');
Route::get('/rem_neg/{query}', 'PrefController@rem_pref_neg');
Route::get('/add_art/{query}', 'PrefController@add_pref_art');
Route::get('/rem_art/{query}', 'PrefController@rem_pref_art');

Route::get('chisiamo', function() {
    return view('chisiamo');
  } )->name('chisiamo');

  Route::get('contatti', function() {
    return view('contatti');
  } )->name('contatti');