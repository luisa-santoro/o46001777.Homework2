<html>
    <meta charset="utf-8">
    <link href='<?php echo e(url("https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap")); ?>' rel="stylesheet">
<body style="background-color: black;" >

    <p style="top: 50px;
    display: block;
    position: absolute;
    padding: 22px;
    margin: 2px solid white;
    right: 40%;
    left: 40%;
     display: block;
    text-align: center;
    color: white;
    font-family: 'Work Sans';
    font-size: 20px;
    border: 1px solid;">
 Market View visualizza centinaia di negozi sparsi nel mondo e i prodotti di ognuno!
         Inoltre offre la possibilità di salvare i prodotti preferiti di un determinato negozio, di lavorare come dipendende e la gestione ai manager di una catena.
    </p>

</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/marketview/resources/views/chisiamo.blade.php ENDPATH**/ ?>