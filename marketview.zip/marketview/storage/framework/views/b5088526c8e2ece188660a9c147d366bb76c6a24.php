<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <link rel="stylesheet" href="./css/preferiti.css">
        <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@200&display=swap" rel="stylesheet">
        <script src="./js/preferiti.js" defer></script>
    </head>
    <body>
        <h1> I tuoi preferiti:</h1>
<!-- sezione catene -->
        <section>
            <p style="font-size: 30px;">Catene:</p>
            <div id="box_catene">
                <div id="grid" class="sez_catene">
                </div>
            </div>
        </section>
<!-- sezione negozi -->
        <section>
                <p style="font-size: 30px;">Negozi:</p>
            <div id="box_negozi">
                <div id="grid" class="sez_negozi"></div>
            </div>
        </section>
<!-- sezione articoli-->
        <section>
                <p style="font-size: 30px;">Articoli:</p>
            <div id="box_articoli">
                <div id="grid" class="sez_articolo"></div>
            </div>
        </section>
    </body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/marketview/resources/views/preferiti.blade.php ENDPATH**/ ?>